"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import { SITE } from "@/data/site";
import { Phone, Menu } from "./Icons";

const LINKS = [
  ["#top", "Trang chủ"], ["#gioi-thieu", "Giới thiệu"], ["#dong-xe", "Dòng xe"], ["#bang-gia", "Bảng giá"],
  ["#tra-gop", "Trả góp"], ["#so-sanh", "So sánh"], ["#tin-tuc", "Tin tức"], ["#lien-he", "Liên hệ"],
];

export default function Nav() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("#top");
  useEffect(() => {
    const sections = Array.from(document.querySelectorAll<HTMLElement>("main section[id]"));
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) setActive("#" + en.target.id); });
    }, { rootMargin: "-40% 0px -55% 0px" });
    sections.forEach((s) => io.observe(s));
    return () => io.disconnect();
  }, []);
  return (
    <header className="nav">
      <div className="wrap">
        <a className="logo" href="#top" aria-label={SITE.name}><Image src="/images/logo.png" alt={SITE.name} width={809} height={70} priority style={{ height: 30, width: "auto" }} /></a>
        <nav aria-label="Chính">
          <ul className={`nav-links ${open ? "open" : ""}`}>
            {LINKS.map(([href, label]) => (
              <li key={href}><a href={href} className={active === href ? "active" : ""} onClick={() => setOpen(false)}>{label}</a></li>
            ))}
          </ul>
        </nav>
        <div className="nav-right">
          <a className="hotline" href={SITE.phoneTel}><Phone /><span>Hotline / Zalo<strong>{SITE.phoneDisplay}</strong></span></a>
          <a className="btn btn-red btn-sm" href="#lai-thu">Đăng ký lái thử</a>
          <button className="menu-btn" aria-label="Mở menu" aria-expanded={open} onClick={() => setOpen((o) => !o)}><Menu /></button>
        </div>
      </div>
    </header>
  );
}
