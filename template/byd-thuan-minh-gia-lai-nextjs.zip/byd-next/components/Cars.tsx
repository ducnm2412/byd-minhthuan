"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import { CARS, fmtPrice, fmtKm, type Car } from "@/data/cars";
import { Seat, Range, Bolt, Close } from "./Icons";
import { selectModel } from "./toast";

const FILTERS = [["all", "Tất cả"], ["ev", "Điện thuần (EV)"], ["dmi", "Hybrid DM-i"], ["mpv", "MPV 7 chỗ"]] as const;
type Filter = (typeof FILTERS)[number][0];

export default function Cars() {
  const [filter, setFilter] = useState<Filter>("all");
  const [detail, setDetail] = useState<Car | null>(null);
  const match = (c: Car) => filter === "all" || c.cat.includes(filter as "ev");
  const withImg = CARS.filter((c) => c.img && match(c));
  const others = CARS.filter((c) => !c.img && match(c));

  useEffect(() => {
    document.body.style.overflow = detail ? "hidden" : "";
    const k = (e: KeyboardEvent) => { if (e.key === "Escape") setDetail(null); };
    document.addEventListener("keydown", k); return () => document.removeEventListener("keydown", k);
  }, [detail]);

  return (
    <section className="section" id="dong-xe">
      <div className="wrap">
        <div className="sec-head">
          <h2>Dòng xe tại đại lý</h2>
          <p>Chọn theo nhu cầu: điện thuần cho đô thị, hybrid DM-i cho đường dài, MPV cho gia đình đông người.</p>
        </div>
        <div className="filters" role="tablist" aria-label="Lọc dòng xe">
          {FILTERS.map(([k, label]) => (
            <button key={k} role="tab" aria-selected={filter === k} className={`chip ${filter === k ? "active" : ""}`} onClick={() => setFilter(k)}>{label}</button>
          ))}
        </div>
        <div className="cars">
          {withImg.map((c) => (
            <article className="car-card" key={c.id}>
              <div className="img">
                <Image src={c.img!} alt={c.name} width={900} height={560} />
                {c.badge && <span className={`badge ${c.isNew ? "new" : ""}`}>{c.badge}</span>}
              </div>
              <div className="car-body">
                <div><h4>{c.name}</h4><div className="type">{c.type}</div></div>
                <div className="specs"><span><Seat />{c.seats} chỗ</span><span><Range />{fmtKm(c.range)} km</span><span><Bolt />{c.power}</span></div>
                <div className="price"><b>{fmtPrice(c)}</b><small>{c.price ? "giá niêm yết" : "liên hệ đại lý"}</small></div>
                <div className="car-actions">
                  <button className="btn btn-outline btn-sm" onClick={() => setDetail(c)}>Chi tiết</button>
                  <a className="btn btn-red btn-sm" href="#lai-thu" onClick={() => selectModel("testdrive", c.id)}>Lái thử</a>
                </div>
              </div>
            </article>
          ))}
          {others.length > 0 && (
            <article className="car-card cta">
              <h4>Thêm {others.length} mẫu khác đang có tại đại lý</h4>
              <p>Ảnh thực tế đang cập nhật. Chạm để xem thông số hoặc đặt lịch xem xe trực tiếp.</p>
              <div className="models">
                {others.map((c) => <button key={c.id} className="chip" style={{ background: "transparent", color: "#fff", borderColor: "rgba(255,255,255,.25)" }} onClick={() => setDetail(c)}>{c.name.replace("BYD ", "")}</button>)}
              </div>
              <div style={{ marginTop: 22 }}><a className="btn btn-red btn-sm" href="#lien-he">Hẹn xem xe tại showroom</a></div>
            </article>
          )}
        </div>
      </div>

      {detail && <CarModal car={detail} onClose={() => setDetail(null)} />}
    </section>
  );
}

function CarModal({ car: c, onClose }: { car: Car; onClose: () => void }) {
  const rows: [string, string][] = [
    ["Hệ truyền động", c.power], ["Số chỗ", `${c.seats} chỗ`], ["Quãng đường", `${fmtKm(c.range)} km`], ["Tiêu hao", c.fuel],
    ["Công suất", `${c.hp} hp`], ["Pin", c.battery], ["Chiều dài", `${fmtKm(c.length)} mm`], ["Sạc", c.charge], ["Dẫn động", c.drive], ["Bảo hành pin", "8 năm (tham khảo)"],
  ];
  return (
    <div className="modal open" role="dialog" aria-modal="true" aria-labelledby="mTitle" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-box">
        <button className="close" aria-label="Đóng" onClick={onClose} autoFocus><Close /></button>
        <div className="m-hero"><Image src={c.img ?? "/images/grille.jpg"} alt={c.name} width={900} height={450} /></div>
        <div className="m-content">
          <h3 id="mTitle">{c.name}</h3>
          <div className="type">{c.type}</div>
          <div className="mprice">{fmtPrice(c)}<small>{c.price ? "giá niêm yết, chưa lăn bánh" : "đại lý báo giá theo phiên bản"}</small></div>
          <div className="spec-table">{rows.map(([k, v]) => <div key={k}><span>{k}</span><b>{v}</b></div>)}</div>
          <div className="m-actions">
            <a className="btn btn-red" href="#lai-thu" onClick={() => { selectModel("testdrive", c.id); onClose(); }}>Đăng ký lái thử</a>
            <a className="btn btn-outline" href="#bao-gia" onClick={() => { selectModel("quote", c.id); onClose(); }}>Nhận báo giá</a>
            <a className="btn btn-outline" href="#so-sanh" onClick={() => { selectModel("compareA", c.id); onClose(); }}>So sánh</a>
          </div>
        </div>
      </div>
    </div>
  );
}
