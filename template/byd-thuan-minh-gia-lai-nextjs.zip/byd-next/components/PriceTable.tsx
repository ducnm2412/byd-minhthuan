const EV = [["BYD Dolphin", "Hatchback 5 chỗ · GLX", "569 triệu"], ["BYD Atto 2", "SUV đô thị 5 chỗ", "669 triệu"], ["BYD M6", "MPV điện 7 chỗ", "756 triệu"], ["BYD Seal", "Sedan thể thao · Advanced", "1,119 tỷ"]];
const DMI = [["BYD Seal 5 DM-i", "Sedan 5 chỗ", "696 triệu"], ["BYD Sealion 5 DM-i", "SUV 5 chỗ · mới ra mắt", "Nhận báo giá"], ["BYD Sealion 6 DM-i", "SUV 5 chỗ · Dynamic", "799 triệu"], ["BYD Sealion 8 DM-i", "SUV 7 chỗ · Performance", "1,569 tỷ"], ["BYD M9 DM-i", "MPV cao cấp 7 chỗ · Advanced", "1,999 tỷ"]];
const Box = ({ title, desc, rows }: { title: string; desc: string; rows: string[][] }) => (
  <div className="price-box">
    <h4><i />{title}</h4>
    <p className="desc">{desc}</p>
    <div className="rows">{rows.map(([n, s, p]) => <div className="row" key={n}><span>{n}<small>{s}</small></span><b className={p.startsWith("Nhận") ? "red" : ""}>{p}</b></div>)}</div>
  </div>
);
export default function PriceTable() {
  return (
    <section className="section dark" id="bang-gia">
      <div className="wrap">
        <div className="sec-head">
          <h2>Bảng giá tham khảo</h2>
          <p>Giá niêm yết toàn quốc, chưa gồm chi phí lăn bánh. Ưu đãi riêng của đại lý xin liên hệ trực tiếp.</p>
        </div>
        <div className="price-grid">
          <Box title="Xe điện thuần (EV)" desc="Sạc tại nhà, chi phí vận hành thấp, phù hợp di chuyển nội tỉnh." rows={EV} />
          <Box title="Hybrid sạc ngoài (DM-i)" desc="Chạy điện trong phố, chạy xăng đường dài, không phụ thuộc trạm sạc." rows={DMI} />
        </div>
        <p className="price-note">Cập nhật tháng 10/2026. Giá có thể thay đổi theo chương trình của BYD Việt Nam và đại lý.</p>
        <div style={{ textAlign: "center", marginTop: 20 }}><a className="btn btn-red" href="#bao-gia">Nhận báo giá lăn bánh</a></div>
      </div>
    </section>
  );
}
