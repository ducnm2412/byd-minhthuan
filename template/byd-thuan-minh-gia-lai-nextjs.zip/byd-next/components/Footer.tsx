import Image from "next/image";
import { SITE } from "@/data/site";
import { Facebook, Chat, Pin } from "./Icons";
export default function Footer() {
  return (
    <footer>
      <div className="wrap">
        <div className="f-grid">
          <div>
            <Image src="/images/logo.png" alt={SITE.name} width={809} height={70} style={{ height: 32, width: "auto" }} />
            <p>Đại lý ủy quyền BYD tại Gia Lai. Kinh doanh ô tô BYD, tư vấn mua xe, đăng ký lái thử, hỗ trợ trả góp và dịch vụ hậu mãi, bảo dưỡng.</p>
            <div className="social">
              <a href={SITE.facebook} target="_blank" rel="noopener" aria-label="Facebook"><Facebook /></a>
              <a href={SITE.zalo} target="_blank" rel="noopener" aria-label="Zalo"><Chat /></a>
              <a href={SITE.maps} target="_blank" rel="noopener" aria-label="Google Maps"><Pin /></a>
            </div>
          </div>
          <div><h5>Dòng xe</h5><ul>
            {["BYD Sealion 5 DM-i", "BYD Seal 5 DM-i", "BYD Dolphin", "BYD Atto 2", "BYD M6", "BYD M9"].map((n) => <li key={n}><a href="#dong-xe">{n}</a></li>)}</ul></div>
          <div><h5>Dịch vụ</h5><ul>
            <li><a href="#lai-thu">Đăng ký lái thử</a></li><li><a href="#bao-gia">Nhận báo giá</a></li><li><a href="#tra-gop">Tư vấn trả góp</a></li><li><a href="#so-sanh">So sánh xe</a></li><li><a href="#lien-he">Bảo dưỡng, hậu mãi</a></li></ul></div>
          <div><h5>Liên hệ</h5><ul>
            <li><a href={SITE.maps} target="_blank" rel="noopener">{SITE.address}</a></li>
            <li><a href={SITE.phoneTel}>Hotline / Zalo: {SITE.phoneDisplay}</a></li>
            <li><a href={SITE.facebook} target="_blank" rel="noopener">facebook.com/bydthuanminhgialai</a></li>
            <li><a href="#lien-he">Giờ mở cửa: 8:00 – 18:00 hằng ngày</a></li></ul></div>
        </div>
        <div className="f-bottom"><span>© 2026 {SITE.name}. Bảo lưu mọi quyền.</span><span>BYD và logo BYD là thương hiệu của BYD Company Ltd.</span></div>
      </div>
      <div className="f-red" />
    </footer>
  );
}
