import Image from "next/image";
import { SITE } from "@/data/site";
const POSTS = [
  { img: "/images/news1.jpg", tag: "Sự kiện", date: "2026-10-10", d: "10/10/2026", t: "Sealion 5 DM-i First Meet: ra mắt tại Pleiku, đặc quyền sở hữu 100 triệu", s: "Khách tham dự được lái thử sớm, nhận ưu đãi cọc và quà tặng khi đặt xe trong ngày sự kiện." },
  { img: "/images/news2.jpg", tag: "Ưu đãi", date: "2026-09-20", d: "20/09/2026", t: "Ưu đãi Trung Thu 2026 cho khách đặt cọc trong tháng", s: "Tặng gói phụ kiện và hỗ trợ phí trước bạ cho các dòng Dolphin, Atto 2, Seal 5 và M6." },
  { img: "/images/news3.jpg", tag: "Showroom", date: "2026-09-06", d: "06/09/2026", t: "Cuối tuần ghé showroom: lái thử, tham quan và tư vấn sạc tại nhà", s: "Không gian trưng bày đủ dòng xe, khu vui chơi cho trẻ, cà phê miễn phí cho gia đình." },
];
export default function News() {
  return (
    <section className="section mist" id="tin-tuc">
      <div className="wrap">
        <div className="sec-head"><h2>Tin tức và ưu đãi</h2><p>Sự kiện ra mắt, chương trình khuyến mãi và hoạt động của đại lý.</p></div>
        <div className="news">
          {POSTS.map((p) => (
            <article className="n-card" key={p.t}>
              <Image src={p.img} alt={p.t} width={800} height={450} />
              <div className="n-body">
                <span className="n-tag">{p.tag}</span><time dateTime={p.date}>{p.d}</time>
                <h4>{p.t}</h4><p>{p.s}</p>
                <a className="more" href="#lien-he">Xem chi tiết</a>
              </div>
            </article>
          ))}
        </div>
        <div style={{ textAlign: "center", marginTop: 30 }}><a className="btn btn-dark" href={SITE.facebook} target="_blank" rel="noopener">Xem thêm trên Facebook</a></div>
      </div>
    </section>
  );
}
