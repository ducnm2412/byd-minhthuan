import { CARS, fmtPrice } from "@/data/cars";
type Props = React.SelectHTMLAttributes<HTMLSelectElement> & { priceOnly?: boolean };
export default function ModelSelect({ priceOnly, ...rest }: Props) {
  const list = priceOnly ? CARS.filter((c) => c.price) : CARS;
  return (
    <select className="model-select" {...rest}>
      {list.map((c) => <option key={c.id} value={c.id}>{c.name}{c.price ? ` – ${fmtPrice(c)}` : ""}</option>)}
    </select>
  );
}
