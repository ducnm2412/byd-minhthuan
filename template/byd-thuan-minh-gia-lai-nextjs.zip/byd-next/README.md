# BYD Thuận Minh Gia Lai – Website (Next.js 15, App Router, TypeScript)

## Chạy dự án
```bash
npm install
npm run dev      # http://localhost:3000
npm run build && npm start
```

## Cấu trúc
```
app/
  layout.tsx       # font Be Vietnam Pro (next/font), metadata, viewport
  page.tsx         # ghép các section theo thứ tự trang chủ
  globals.css      # toàn bộ design tokens + style (hỗ trợ dark mode)
components/
  Nav.tsx          # menu sticky, scroll-spy, hamburger mobile
  Hero.tsx         # hero + dải thông số
  TestDriveForm.tsx# form đăng ký lái thử (client)
  Why.tsx, Tech.tsx, Stats.tsx
  Cars.tsx         # lưới dòng xe, bộ lọc, modal chi tiết/thông số (client)
  PriceTable.tsx   # bảng giá tham khảo
  Finance.tsx      # máy tính trả góp (client)
  Compare.tsx      # so sánh 2 xe (client)
  Testimonials.tsx, News.tsx, CtaBand.tsx
  QuoteContact.tsx # form báo giá + liên hệ + Google Maps (client)
  Footer.tsx, Fab.tsx (Zalo/Hotline nổi), Toast.tsx
  ModelSelect.tsx, Icons.tsx, toast.ts (toast + bus chọn model giữa các section)
data/
  cars.ts          # danh sách xe + thông số + giá (chỉnh ở đây)
  site.ts          # SĐT, Zalo, Facebook, Google Maps, địa chỉ
public/images/     # ảnh đã tối ưu từ tư liệu đại lý
```

## Việc cần làm trước khi lên production
- Nối form về backend: tạo `app/api/lead/route.ts` và gọi `fetch("/api/lead", {method:"POST"})` trong `TestDriveForm.tsx`, `QuoteContact.tsx` (gửi Zalo OA / Google Sheet / email).
- Xác nhận giá, thông số, giờ mở cửa, chính sách bảo hành/trả góp với đại lý (các số đang ghi "tham khảo").
- Bổ sung ảnh sản phẩm cho Atto 2, Sealion 6, Sealion 8, Seal; thay ảnh Seal 5 bằng ảnh xe không có người.
- Thay 3 đánh giá khách hàng mẫu bằng đánh giá thật.
- Nhúng Google Maps iframe nếu muốn bản đồ trực tiếp (hiện là link mở Google Maps).
