import type { Metadata, Viewport } from "next";
import { Be_Vietnam_Pro } from "next/font/google";
import "./globals.css";

const font = Be_Vietnam_Pro({ subsets: ["latin", "vietnamese"], weight: ["400", "500", "600", "700", "800"], display: "swap", variable: "--font-bvp" });

export const metadata: Metadata = {
  title: "BYD Thuận Minh Gia Lai – Đại lý ô tô BYD tại Pleiku",
  description: "Đại lý BYD Thuận Minh Gia Lai: kinh doanh ô tô BYD, tư vấn mua xe, đăng ký lái thử, hỗ trợ trả góp, bảo dưỡng hậu mãi. 662A Lê Duẩn, Pleiku, Gia Lai. Hotline 093 161 26 79.",
  openGraph: { title: "BYD Thuận Minh Gia Lai", description: "Đại lý ô tô BYD tại Pleiku, Gia Lai. Lái thử, báo giá, trả góp.", images: ["/images/hero.jpg"], locale: "vi_VN", type: "website" },
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, viewportFit: "cover", themeColor: "#0F0F10" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="vi" className={font.variable}>
      <body>{children}</body>
    </html>
  );
}
