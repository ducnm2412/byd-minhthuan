import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import TestDriveForm from "@/components/TestDriveForm";
import Why from "@/components/Why";
import Tech from "@/components/Tech";
import Stats from "@/components/Stats";
import Cars from "@/components/Cars";
import PriceTable from "@/components/PriceTable";
import Finance from "@/components/Finance";
import Compare from "@/components/Compare";
import Testimonials from "@/components/Testimonials";
import News from "@/components/News";
import CtaBand from "@/components/CtaBand";
import QuoteContact from "@/components/QuoteContact";
import Footer from "@/components/Footer";
import Fab from "@/components/Fab";
import Toast from "@/components/Toast";

export default function Page() {
  return (
    <>
      <Nav />
      <main id="top">
        <Hero />
        <TestDriveForm />
        <Why />
        <Tech />
        <Stats />
        <Cars />
        <PriceTable />
        <Finance />
        <Compare />
        <Testimonials />
        <News />
        <CtaBand />
        <QuoteContact />
      </main>
      <Footer />
      <Fab />
      <Toast />
    </>
  );
}
